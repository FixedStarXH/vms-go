import request from '@/utils/request';

export interface RecordQueryParams {
  name?: string;
  phone?: string;
  idCard?: string;
  status?: string;
  startTime?: string;
  endTime?: string;
  page?: number;
  pageSize?: number;
}

export interface RecordItem {
  id: number;
  name: string;
  recordNo: string;
  phone: string;
  inTime: string;
  outTime: string;
  status: string;
  detail?: {
    college?: string;
    className?: string;
    purpose?: string;
    auditor?: string;
  };
}

export const getRecordList = (params: RecordQueryParams) => {
  return request({
    url: '/admin/record/list/',
    method: 'GET',
    params,
  });
};

export const deleteRecord = (id: number) => {
  return request({
    url: `/admin/record/delete/${id}/`,
    method: 'DELETE',
  });
};

export const exportRecord = (params: RecordQueryParams) => {
  return request({
    url: '/admin/record/export/',
    method: 'GET',
    params,
    responseType: 'blob',
  });
};