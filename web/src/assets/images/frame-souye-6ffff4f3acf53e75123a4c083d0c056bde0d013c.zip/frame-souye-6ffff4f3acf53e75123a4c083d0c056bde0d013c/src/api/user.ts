import request from '@/utils/request';

export interface UserInfo {
  id: number;
  username: string;
  nickname?: string;
  avatar?: string;
  email?: string;
  phone?: string;
  role?: string;
  createTime?: string;
  updateTime?: string;
}

export const getUserInfo = () => {
  return request({
    url: '/admin/user/info/',
    method: 'GET',
  });
};

export const login = (data: { username: string; password: string }) => {
  return request({
    url: '/admin/user/login/',
    method: 'POST',
    data,
  });
};

export const logout = () => {
  return request({
    url: '/admin/user/logout/',
    method: 'POST',
  });
};