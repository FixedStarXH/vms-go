import request from '@/utils/request';

export interface VisitorInfo {
  id: number;
  name: string;
  phone: string;
  idCard?: string;
  college?: string;
  className?: string;
  purpose?: string;
  inTime?: string;
  outTime?: string;
  status?: string;
  createTime?: string;
  updateTime?: string;
}

export interface VisitorUpdateParams {
  name?: string;
  phone?: string;
  idCard?: string;
  college?: string;
  className?: string;
  purpose?: string;
  inTime?: string;
  outTime?: string;
  status?: string;
}

export interface VisitorListParams {
  page?: number;
  pageSize?: number;
  name?: string;
  phone?: string;
  idCard?: string;
  status?: string;
}

export interface VisitorListResult {
  list: VisitorInfo[];
  total: number;
}

export const getVisitorList = (params: VisitorListParams): Promise<VisitorListResult> => {
  return request({
    url: '/admin/visitor/list',
    method: 'GET',
    params,
  });
};

export const getVisitorDetail = (id: number) => {
  return request({
    url: `/admin/visitor/detail/${id}`,
    method: 'GET',
  });
};

export const updateVisitor = (id: number, data: VisitorUpdateParams) => {
  return request({
    url: `/admin/visitor/update/${id}`,
    method: 'PUT',
    data,
  });
};

export const deleteVisitor = (id: number) => {
  return request({
    url: `/admin/visitor/delete/${id}`,
    method: 'DELETE',
  });
};

export const getUserInfo = () => {
  return request({
    url: '/admin/user/info/',
    method: 'GET',
  });
};