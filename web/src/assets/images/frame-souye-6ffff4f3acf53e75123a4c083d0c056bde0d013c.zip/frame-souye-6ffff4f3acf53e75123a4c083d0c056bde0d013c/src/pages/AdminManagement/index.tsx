import React, { useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import HomePage from './home/index';
import RecordPage from './record/index';
import AdminLayout from '@/layouts/AdminLayout';

// 页面类型定义
type PageType = 'home' | 'account-list' | 'account-add' | 'account-password' | 'query-record' | 'settings' | 'approval';

const AdminManagement: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<PageType>('home');

  // 渲染当前页面内容
  const renderPageContent = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onPageChange={setCurrentPage} />;
      case 'query-record':
        return <RecordPage />;
      case 'account-list':
        return (
          <div style={{ padding: '20px' }}>
            <h2>账号列表</h2>
            <p>页面开发中...</p>
          </div>
        );
      case 'account-add':
        return (
          <div style={{ padding: '20px' }}>
            <h2>添加管理员账号</h2>
            <p>页面开发中...</p>
          </div>
        );
      case 'account-password':
        return (
          <div style={{ padding: '20px' }}>
            <h2>修改管理员密码</h2>
            <p>页面开发中...</p>
          </div>
        );
      case 'settings':
        return (
          <div style={{ padding: '20px' }}>
            <h2>系统设置</h2>
            <p>页面开发中...</p>
          </div>
        );
      case 'approval':
        return (
          <div style={{ padding: '20px' }}>
            <h2>审批申请</h2>
            <p>页面开发中...</p>
          </div>
        );
      default:
        return <HomePage onPageChange={setCurrentPage} />;
    }
  };

  return (
    <AdminLayout onPageChange={setCurrentPage}>
      {renderPageContent()}
    </AdminLayout>
  );
};

export default AdminManagement;