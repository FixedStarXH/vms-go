import React from 'react';
import { Card, Carousel } from 'antd';
import AdminLayout from '@/layouts/AdminLayout';
import styles from './home.module.scss';
import campus1 from '@/assets/images/OIP-C.we.jpg';
import campus2 from '@/assets/images/OIP-C.web.jpg';
import campus3 from '@/assets/images/OIP-C.jpg';

interface HomePageProps {
    onPageChange: (page: string) => void;
}

const HomePage: React.FC<HomePageProps> = ({ onPageChange }) => {
    return (
        <AdminLayout onPageChange={onPageChange}>
            {/* 轮播图 */}
            <Carousel autoplay className={styles.carousel}>
                <div>
                    <img src={campus1} alt="校园风景1" className={styles.carouselImg} />
                </div>
                <div>
                    <img src={campus2} alt="校园风景2" className={styles.carouselImg} />
                </div>
                <div>
                    <img src={campus3} alt="校园风景3" className={styles.carouselImg} />
                </div>
            </Carousel>

            {/* 系统功能说明 */}
            <Card className={styles.functionCard}>
                <h2 className={styles.functionTitle}>系统功能说明</h2>

                <div className={styles.functionItem}>
                    <h3>1. 数据可视化</h3>
                    <ul>
                        <li>展示系统关键数据的图表分析</li>
                        <li>提供直观的数据趋势和统计信息</li>
                    </ul>
                </div>

                <div className={styles.functionItem}>
                    <h3>2. 账号管理</h3>
                    <ul>
                        <li>账号列表：查看和管理所有用户账号</li>
                        <li>添加账号：创建新的系统用户账号</li>
                        <li>重置密码：为忘记密码的用户重置登录凭证</li>
                    </ul>
                </div>

                <div className={styles.functionItem}>
                    <h3>3. 审批申请</h3>
                    <ul>
                        <li>提交各类审批申请</li>
                        <li>查看申请处理状态</li>
                        <li>审批流程：管理员审核并处理申请</li>
                    </ul>
                </div>

                <div className={styles.functionItem}>
                    <h3>4. 查询统计</h3>
                    <ul>
                        <li>入校记录：查询所有入校登记信息</li>
                        <li>数据报表：生成各类统计报表</li>
                    </ul>
                </div>

                <div className={styles.functionItem}>
                    <h3>5. 系统设置</h3>
                    <ul>
                        <li>基础设置：配置系统基础参数</li>
                        <li>安全设置：管理账号安全和权限</li>
                    </ul>
                </div>
            </Card>
        </AdminLayout>
    );
};

export default HomePage;
