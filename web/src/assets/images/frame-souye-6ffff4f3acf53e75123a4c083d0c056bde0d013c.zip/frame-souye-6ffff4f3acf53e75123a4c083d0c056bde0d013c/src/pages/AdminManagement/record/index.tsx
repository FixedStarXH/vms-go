import React, { useState, useEffect } from 'react';
import { Card, Form, Input, Select, DatePicker, Button, Table, Pagination, message, Modal, Drawer } from 'antd';
import { SearchOutlined, DownloadOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons';
import { getVisitorList, updateVisitor, deleteVisitor, type VisitorInfo, type VisitorListParams } from '@/api/visitor';
import styles from './record.module.scss';

const { RangePicker } = DatePicker;
const { Option } = Select;

// 状态标签组件
const StatusTag: React.FC<{ status: string | number }> = ({ status }) => {
    // 状态映射
    const statusMap: Record<string | number, { color: string; text: string }> = {
        1: { color: '#52c41a', text: '已通过' },
        2: { color: '#f5222d', text: '未通过' },
        3: { color: '#1890ff', text: '已爽约' },
        0: { color: '#faad14', text: '待审核' },
        approved: { color: '#52c41a', text: '已通过' },
        rejected: { color: '#f5222d', text: '未通过' },
        checkedIn: { color: '#1890ff', text: '已爽约' },
        pending: { color: '#faad14', text: '待审核' },
    };

    const config = statusMap[status] || statusMap[0];

    return (
        <span style={{
            display: 'inline-block',
            padding: '2px 8px',
            borderRadius: '4px',
            backgroundColor: config.color,
            color: 'white',
            fontSize: '12px',
        }}>
            {config.text}
        </span>
    );
};

const RecordPage: React.FC = () => {
    const [form] = Form.useForm();
    const [editForm] = Form.useForm();
    const [data, setData] = useState<VisitorInfo[]>([]);
    const [loading, setLoading] = useState(false);
    const [current, setCurrent] = useState(1);
    const [pageSize] = useState(10);
    const [total, setTotal] = useState(0);
    const [editDrawerVisible, setEditDrawerVisible] = useState(false);
    const [currentEditId, setCurrentEditId] = useState<number | null>(null);

    // 1. 页面加载时获取列表
    useEffect(() => {
        fetchList();
    }, [current, pageSize]);

    // 2. 获取列表数据
    const fetchList = async (params?: Partial<VisitorListParams>) => {
        setLoading(true);
        try {
            const formValues = form.getFieldsValue();
            const queryParams: VisitorListParams = {
                page: current,
                pageSize,
                name: formValues.name,
                phone: formValues.phone,
                idCard: formValues.idCard,
                status: formValues.status,
                ...params,
            };

            const res = await getVisitorList(queryParams);

            // 处理Apifox返回的数据格式，映射字段
            const formattedData = (res.list || []).map(item => {
                // 生成记录编号
                const recordNo = `AP${Date.now().toString().slice(-6)}${item.id?.toString().padStart(4, '0')}`;

                // 生成随机的进校和离校时间
                const now = new Date();
                const inTime = new Date(now.getTime() - Math.random() * 7 * 24 * 60 * 60 * 1000);
                const outTime = new Date(inTime.getTime() + Math.random() * 8 * 60 * 60 * 1000);

                return {
                    id: item.id,
                    name: item.realName || item.name || '未知',
                    recordNo: recordNo,
                    phone: item.phone || '',
                    idCard: item.idCard || '',
                    inTime: inTime.toLocaleString('zh-CN'),
                    outTime: outTime.toLocaleString('zh-CN'),
                    status: item.status || 0,
                    statusText: item.statusText || '',
                    college: item.college || '计算机科学与技术学院',
                    className: item.className || '软件工程1班',
                    purpose: item.purpose || '参观访问',
                    auditor: item.auditor || '管理员',
                };
            });

            setData(formattedData);
            setTotal(res.total || 0);
        } catch (err) {
            message.error('查询失败，请稍后重试');
        } finally {
            setLoading(false);
        }
    };

    // 3. 查询按钮点击
    const handleQuery = () => {
        setCurrent(1); // 查询时重置到第一页
        fetchList();
    };

    // 4. 一键筛选当天入校
    const handleTodayQuery = () => {
        const today = new Date();
        const start = new Date(today.setHours(0, 0, 0, 0));
        const end = new Date(today.setHours(23, 59, 59, 999));
        form.setFieldsValue({
            timeRange: [start, end],
        });
        handleQuery();
    };

    // 5. 生成数据报表
    const handleExport = () => {
        message.success('报表导出成功');
        // 真实项目：调用导出接口
    };

    // 6. 打开编辑弹窗
    const handleEdit = (record: VisitorInfo) => {
        setCurrentEditId(record.id);
        editForm.setFieldsValue(record);
        setEditDrawerVisible(true);
    };

    // 7. 提交编辑
    const handleEditSubmit = async () => {
        try {
            const values = await editForm.validateFields();
            if (!currentEditId) return;

            await updateVisitor(currentEditId, values);
            message.success('修改成功');
            setEditDrawerVisible(false);
            fetchList(); // 刷新列表
        } catch (err) {
            message.error('修改失败，请稍后重试');
        }
    };

    // 8. 删除记录
    const handleDelete = (id: number) => {
        Modal.confirm({
            title: '确认删除',
            content: '确定要删除这条入校记录吗？删除后无法恢复',
            onOk: async () => {
                try {
                    await deleteVisitor(id);
                    message.success('删除成功');
                    fetchList(); // 刷新列表
                } catch (err) {
                    message.error('删除失败，请稍后重试');
                }
            },
        });
    };

    // 表格列配置
    const columns = [
        { title: '姓名', dataIndex: 'name', key: 'name' },
        { title: '记录编号', dataIndex: 'recordNo', key: 'recordNo' },
        { title: '手机号', dataIndex: 'phone', key: 'phone' },
        { title: '进校时间', dataIndex: 'inTime', key: 'inTime' },
        { title: '离校时间', dataIndex: 'outTime', key: 'outTime' },
        {
            title: '审批状态',
            dataIndex: 'status',
            key: 'status',
            render: (status) => <StatusTag status={status} />,
        },
        {
            title: '操作',
            key: 'action',
            render: (_, record) => (
                <div style={{ display: 'flex', gap: '8px' }}>
                    <a style={{ color: '#1890ff' }} onClick={() => handleEdit(record)}>
                        <EditOutlined /> 编辑
                    </a>
                    <a style={{ color: '#f5222d' }} onClick={() => handleDelete(record.id)}>
                        <DeleteOutlined /> 删除
                    </a>
                </div>
            ),
        },
    ];

    return (
        <div>
            <Card className={styles.pageCard}>
                <h2 className={styles.pageTitle}>查询入校记录</h2>

                {/* 查询筛选区 */}
                <Form
                    form={form}
                    layout="inline"
                    onFinish={handleQuery}
                    className={styles.queryForm}
                >
                    <Form.Item name="name" label="姓名">
                        <Input placeholder="姓名" />
                    </Form.Item>

                    <Form.Item name="phone" label="手机号">
                        <Input placeholder="手机号" />
                    </Form.Item>

                    <Form.Item name="idCard" label="身份证号">
                        <Input placeholder="身份证号" />
                    </Form.Item>

                    <Form.Item name="status" label="审批状态">
                        <Select placeholder="审批状态" style={{ width: 140 }}>
                            <Option value="0">待审核</Option>
                            <Option value="1">已通过</Option>
                            <Option value="2">未通过</Option>
                            <Option value="3">已爽约</Option>
                        </Select>
                    </Form.Item>

                    <Form.Item name="timeRange" label="选择时间">
                        <RangePicker showTime format="YYYY-MM-DD HH:mm" placeholder={['开始日期时间', '结束日期时间']} />
                    </Form.Item>

                    <Form.Item>
                        <Button type="primary" htmlType="submit" icon={<SearchOutlined />}>
                            查询
                        </Button>
                        <Button type="primary" onClick={handleTodayQuery} style={{ marginLeft: 8 }}>
                            一键筛选当天入校
                        </Button>
                        <Button type="primary" onClick={handleExport} icon={<DownloadOutlined />} style={{ marginLeft: 8 }}>
                            生成数据报表
                        </Button>
                    </Form.Item>
                </Form>

                {/* 数据表格 */}
                <Table
                    columns={columns}
                    dataSource={data}
                    rowKey="id"
                    loading={loading}
                    pagination={false}
                    bordered
                    size="middle"
                    expandable={{
                        expandedRowRender: (record) => (
                            <div style={{ padding: '10px 20px' }}>
                                <p>学院：{record.college}</p>
                                <p>班级：{record.className}</p>
                                <p>来访事由：{record.purpose}</p>
                                <p>审批人：{record.auditor}</p>
                            </div>
                        ),
                    }}
                    locale={{
                        emptyText: (
                            <div style={{ padding: '50px 0', color: '#999' }}>
                                暂无入校记录
                            </div>
                        ),
                    }}
                    className={styles.table}
                />

                {/* 分页控件 */}
                <div className={styles.pagination}>
                    <Pagination
                        current={current}
                        pageSize={pageSize}
                        total={total}
                        showTotal={(total) => `共 ${total} 条`}
                        showQuickJumper
                        onChange={(page) => {
                            setCurrent(page);
                        }}
                    />
                </div>
            </Card>

            {/* 编辑弹窗 */}
            <Drawer
                title="编辑访客信息"
                placement="right"
                onClose={() => setEditDrawerVisible(false)}
                open={editDrawerVisible}
                width={500}
                footer={
                    <div style={{ textAlign: 'right' }}>
                        <Button onClick={() => setEditDrawerVisible(false)} style={{ marginRight: 8 }}>
                            取消
                        </Button>
                        <Button type="primary" onClick={handleEditSubmit}>
                            保存
                        </Button>
                    </div>
                }
            >
                <Form form={editForm} layout="vertical">
                    <Form.Item name="name" label="姓名" rules={[{ required: true, message: '请输入姓名' }]}>
                        <Input placeholder="请输入姓名" />
                    </Form.Item>
                    <Form.Item name="phone" label="手机号" rules={[{ required: true, message: '请输入手机号' }]}>
                        <Input placeholder="请输入手机号" />
                    </Form.Item>
                    <Form.Item name="idCard" label="身份证号">
                        <Input placeholder="请输入身份证号" />
                    </Form.Item>
                    <Form.Item name="college" label="学院">
                        <Input placeholder="请输入学院" />
                    </Form.Item>
                    <Form.Item name="className" label="班级">
                        <Input placeholder="请输入班级" />
                    </Form.Item>
                    <Form.Item name="purpose" label="来访事由">
                        <Input.TextArea placeholder="请输入来访事由" rows={3} />
                    </Form.Item>
                    <Form.Item name="status" label="审批状态">
                        <Select placeholder="请选择审批状态">
                            <Option value={0}>待审核</Option>
                            <Option value={1}>已通过</Option>
                            <Option value={2}>未通过</Option>
                            <Option value={3}>已爽约</Option>
                        </Select>
                    </Form.Item>
                </Form>
            </Drawer>
        </div>
    );
};

export default RecordPage;