import axios from 'axios';
import { message } from 'antd';

const request = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL,
  timeout: 10000,
});

request.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

request.interceptors.response.use(
  (response) => {
    const res = response.data;
    // 检查是否有 data 字段，有的话直接返回
    if (res.data) {
      return res.data;
    } else {
      // 没有 data 字段，返回整个响应
      return res;
    }
  },
  (error) => {
    if (error.response?.status === 401) {
      message.error('未登录，请先登录');
    } else if (error.response?.status === 403) {
      message.error('权限不足，无法访问');
    } else {
      message.error(error.message || '网络错误，请检查Apifox服务是否开启');
    }
    return Promise.reject(error);
  }
);

export default request;