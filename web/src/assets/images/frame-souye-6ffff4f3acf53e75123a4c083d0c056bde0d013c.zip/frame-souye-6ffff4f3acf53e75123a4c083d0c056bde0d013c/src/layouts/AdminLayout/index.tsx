import React, { useState, useEffect } from 'react';
import { Layout, Menu, Avatar, Dropdown, Button, message } from 'antd';
import {
    UserOutlined,
    SettingOutlined,
    BarChartOutlined,
    CheckCircleOutlined,
    LogoutOutlined,
    HomeOutlined
} from '@ant-design/icons';
import { getUserInfo } from '@/api/visitor';
import styles from './AdminLayout.module.scss';
import logo from '@/assets/hero.png';

const { Header, Sider, Content } = Layout;

interface SystemLayoutProps {
    children: React.ReactNode;
    onPageChange: (page: string) => void;
}

const SystemLayout: React.FC<SystemLayoutProps> = ({ children, onPageChange }) => {
    const [collapsed, setCollapsed] = useState(false);
    const [currentSelectedKey, setCurrentSelectedKey] = useState('home');
    const [userInfo, setUserInfo] = useState<any>(null);

    useEffect(() => {
        // 模拟获取用户信息，避免调用不存在的接口
        setUserInfo({
            username: 'admin',
            nickname: '管理员',
            avatar: '',
        });
    }, []);

    const fetchUserInfo = async () => {
        try {
            const res = await getUserInfo();
            if (res.code === 200 || res.code === 0) {
                setUserInfo(res.data);
            } else {
                message.error(res.message || '获取用户信息失败');
            }
        } catch (error) {
            console.error('获取用户信息失败:', error);
        }
    };

    const handleLogout = () => {
        localStorage.removeItem('token');
        window.location.href = '/login';
    };

    // 用户下拉菜单
    const userMenuItems = [
        {
            key: 'logout',
            icon: <LogoutOutlined />,
            label: '退出登录',
            onClick: handleLogout,
        },
    ];

    // 侧边栏菜单
    const menuItems = [
        {
            key: 'home',
            icon: <HomeOutlined />,
            label: '系统首页',
        },
        {
            key: 'account',
            icon: <UserOutlined />,
            label: '账号管理',
            children: [
                { key: 'account-list', label: '账号列表' },
                { key: 'account-add', label: '添加管理员账号' },
                { key: 'account-password', label: '修改管理员密码' },
            ],
        },
        {
            key: 'query',
            icon: <BarChartOutlined />,
            label: '查询与统计',
            children: [
                { key: 'query-record', label: '查询入校记录' },
            ],
        },
        {
            key: 'settings',
            icon: <SettingOutlined />,
            label: '系统设置',
        },
        {
            key: 'approval',
            icon: <CheckCircleOutlined />,
            label: '审批申请',
        },
    ];

    // 菜单点击处理
    const handleMenuClick = (e: { key: string }) => {
        setCurrentSelectedKey(e.key);
        onPageChange(e.key);
    };

    return (
        <Layout className={styles.commonLayout} >
            {/* 顶部导航栏 */}
            <Header className={styles.header} >
                {/* Logo 区域 */}
                <div className={styles.logoArea} >
                    <img src={logo} alt="管理系统" className={styles.logoImg} />
                    <h1 className={styles.logoText}> ERS </h1>
                </div>

                {/* 系统名称 */}
                <div className={styles.systemName}>
                    河南科技学院--入校登记系统v1.0.0
                </div>

                {/* 用户信息 */}
                <div className={styles.userArea}>
                    <Dropdown menu={{ items: userMenuItems }} placement="bottomRight" >
                        <Button type="text" className={styles.welcomeText} >
                            欢迎您，{userInfo?.nickname || userInfo?.username || 'admin'}
                        </Button>
                    </Dropdown>
                    <Avatar
                        src={userInfo?.avatar}
                        icon={<UserOutlined />}
                        className={styles.avatar}
                    />
                </div>
            </Header>

            <Layout>
                {/* 左侧侧边栏 */}
                <Sider
                    width="var(--width-sidebar)"
                    collapsible
                    collapsed={collapsed}
                    onCollapse={setCollapsed}
                    trigger={null}
                    className={styles.sider}
                >
                    <Menu
                        mode="inline"
                        selectedKeys={[currentSelectedKey]}
                        defaultOpenKeys={['query']}
                        className={styles.menu}
                        items={menuItems}
                        onClick={handleMenuClick}
                        inlineCollapsed={collapsed}
                    />
                </Sider>

                {/* 主内容区 */}
                <Content className={styles.content}>
                    {children}
                </Content>
            </Layout>
        </Layout>
    );
};

export default SystemLayout;