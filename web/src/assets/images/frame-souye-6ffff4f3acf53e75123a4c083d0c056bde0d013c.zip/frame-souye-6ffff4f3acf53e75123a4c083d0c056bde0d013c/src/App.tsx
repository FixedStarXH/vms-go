import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Carousel } from 'antd';
import AdminLayout from './layouts/AdminLayout';
import RecordPage from './pages/AdminManagement/record';

// 页面类型定义
type PageType = 'home' | 'account-list' | 'account-add' | 'account-password' | 'query-record' | 'settings' | 'approval';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<PageType>('home');

  // 渲染当前页面内容
  const renderPageContent = () => {
    switch (currentPage) {
      case 'home':
        return <HomePageContent />;
      case 'account-list':
        return (
          <div style={{ padding: '20px' }}>
            <h2>账号列表</h2>
            <p>页面开发中...</p>
          </div>
        );
      case 'account-add':
        return (
          <div style={{ padding: '20px' }}>
            <h2>添加管理员账号</h2>
            <p>页面开发中...</p>
          </div>
        );
      case 'account-password':
        return (
          <div style={{ padding: '20px' }}>
            <h2>修改管理员密码</h2>
            <p>页面开发中...</p>
          </div>
        );
      case 'query-record':
        return <RecordPage />;
      case 'settings':
        return (
          <div style={{ padding: '20px' }}>
            <h2>系统设置</h2>
            <p>页面开发中...</p>
          </div>
        );
      case 'approval':
        return (
          <div style={{ padding: '20px' }}>
            <h2>审批申请</h2>
            <p>页面开发中...</p>
          </div>
        );
      default:
        return <HomePageContent />;
    }
  };

  // 首页内容组件
  const HomePageContent: React.FC = () => {
    return (
      <div>
        {/* 轮播图 */}
        <div style={{ marginBottom: '20px', borderRadius: '4px', overflow: 'hidden' }}>
          <Carousel autoplay>
            <div>
              <img
                src="/src/assets/images/OIP-C.jpg"
                alt="校园风景1"
                style={{ width: '100%', height: '300px', objectFit: 'cover' }}
              />
            </div>
            <div>
              <img
                src="/src/assets/images/OIP-C.we.jpg"
                alt="校园风景2"
                style={{ width: '100%', height: '300px', objectFit: 'cover' }}
              />
            </div>
            <div>
              <img
                src="/src/assets/images/OIP-C.web.jpg"
                alt="校园风景3"
                style={{ width: '100%', height: '300px', objectFit: 'cover' }}
              />
            </div>
          </Carousel>
        </div>

        {/* 系统功能说明 */}
        <div style={{ backgroundColor: '#fff', padding: '20px', borderRadius: '4px' }}>
          <h2>系统功能说明</h2>
          <div style={{ marginTop: '15px' }}>
            <h3>1. 数据可视化</h3>
            <ul>
              <li>展示系统关键数据的图表分析</li>
              <li>提供直观的数据趋势和统计信息</li>
            </ul>
          </div>
          <div style={{ marginTop: '15px' }}>
            <h3>2. 账号管理</h3>
            <ul>
              <li>账号列表：查看和管理所有用户账号</li>
              <li>添加账号：创建新的系统用户账号</li>
              <li>重置密码：为忘记密码的用户重置登录凭证</li>
            </ul>
          </div>
          <div style={{ marginTop: '15px' }}>
            <h3>3. 审批申请</h3>
            <ul>
              <li>提交各类审批申请</li>
              <li>查看申请处理状态</li>
              <li>审批流程：管理员审核并处理申请</li>
            </ul>
          </div>
          <div style={{ marginTop: '15px' }}>
            <h3>4. 查询统计</h3>
            <ul>
              <li>入校记录：查询所有入校登记信息</li>
              <li>数据报表：生成各类统计报表</li>
            </ul>
          </div>
          <div style={{ marginTop: '15px' }}>
            <h3>5. 系统设置</h3>
            <ul>
              <li>基础设置：配置系统基础参数</li>
              <li>安全设置：管理账号安全和权限</li>
            </ul>
          </div>
        </div>
      </div>
    );
  };

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/home" replace />} />
        <Route path="/home" element={
          <AdminLayout onPageChange={setCurrentPage}>
            {renderPageContent()}
          </AdminLayout>
        } />
      </Routes>
    </BrowserRouter>
  );
};

export default App;