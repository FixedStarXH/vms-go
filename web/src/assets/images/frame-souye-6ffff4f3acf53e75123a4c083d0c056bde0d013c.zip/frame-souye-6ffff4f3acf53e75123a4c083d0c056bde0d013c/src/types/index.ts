

// 访客信息类型
export interface VisitorItem {
    id: number;
    name: string; // 姓名
    recordNo: string; // 记录编号
    phone: string; // 手机号
    idCard: string; // 身份证号
    inTime: string; // 进校时间
    outTime: string; // 离校时间
    status: 'approved' | 'rejected' | 'checkedIn' | 'pending'; // 审批状态
    college: string; // 学院
    className: string; // 班级
    purpose: string; // 来访事由
    auditor: string; // 审批人
}

// 列表查询参数
export interface VisitorListParams {
    name?: string;
    phone?: string;
    idCard?: string;
    status?: string;
    startTime?: string;
    endTime?: string;
    page: number;
    pageSize: number;
}

// 列表返回结果
export interface VisitorListResult {
    list: VisitorItem[];
    total: number;
}